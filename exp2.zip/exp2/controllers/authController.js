const User = require('../models/User');
const jwt = require('jsonwebtoken');

const register = async (req, res) => {
    const { username, password, role, messId } = req.body;

    try {
        const user = new User({ username, password, role, messId });
        await user.save();

        const token = jwt.sign({ _id: user._id }, process.env.JWT_SECRET);
        res.header('Authorization', 'Bearer ' + token).send({ user, token });
    } catch (error) {
        res.status(400).send(error);
    }
};

const login = async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await User.findOne({ username });
        if (!user || !await user.comparePassword(password)) {
            return res.status(400).send('Invalid credentials');
        }

        const token = jwt.sign({ _id: user._id }, process.env.JWT_SECRET);
        res.header('Authorization', 'Bearer ' + token).send({ user, token });
    } catch (error) {
        res.status(400).send(error);
    }
};

module.exports = { register, login };