const Feedback = require('../models/Feedback');
const User = require('../models/User');

const submitFeedback = async (req, res) => {
    const { messId, content } = req.body;

    try {
        const feedback = new Feedback({
            studentId: req.user._id,
            messId,
            content
        });

        await feedback.save();
        res.send(feedback);
    } catch (error) {
        res.status(400).send(error);
    }
};

const getFeedbacks = async (req, res) => {
    try {
        const feedbacks = await Feedback.find({ messId: req.user.messId }).populate('studentId', '-username');
        res.send(feedbacks);
    } catch (error) {
        res.status(400).send(error);
    }
};

const takeAction = async (req, res) => {
    const { id, action } = req.body;

    try {
        const feedback = await Feedback.findById(id);
        if (!feedback || feedback.messId.toString() !== req.user.messId.toString()) {
            return res.status(404).send('Feedback not found');
        }

        feedback.actionTaken = action;
        await feedback.save();
        res.send(feedback);
    } catch (error) {
        res.status(400).send(error);
    }
};

const getAllFeedbacks = async (req, res) => {
    try {
        const feedbacks = await Feedback.find().populate('studentId', '-username').populate('messId');
        res.send(feedbacks);
    } catch (error) {
        res.status(400).send(error);
    }
};

module.exports = { submitFeedback, getFeedbacks, takeAction, getAllFeedbacks };