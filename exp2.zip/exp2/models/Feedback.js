const mongoose = require('mongoose');

const feedbackSchema = new mongoose.Schema({
    studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    messId: { type: mongoose.Schema.Types.ObjectId, ref: 'Mess', required: true },
    content: { type: String, required: true },
    actionTaken: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Feedback', feedbackSchema);
