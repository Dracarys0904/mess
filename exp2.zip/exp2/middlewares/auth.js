const jwt = require('jsonwebtoken');
const User = require('../models/User');

const auth = (roles = []) => {
    return async (req, res, next) => {
        const token = req.header('Authorization').replace('Bearer ', '');
        if (!token) return res.status(401).send('Access Denied');

        try {
            const verified = jwt.verify(token, process.env.JWT_SECRET);
            req.user = await User.findById(verified._id);

            if (roles.length && !roles.includes(req.user.role)) {
                return res.status(403).send('Permission Denied');
            }

            next();
        } catch (error) {
            res.status(400).send('Invalid Token');
        }
    };
};

module.exports = auth;