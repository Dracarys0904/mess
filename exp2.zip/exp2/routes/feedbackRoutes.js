const express = require('express');
const { submitFeedback, getFeedbacks, takeAction, getAllFeedbacks } = require('../controllers/feedbackController');
const auth = require('../middlewares/auth');
const router = express.Router();

router.post('/', auth(['student']), submitFeedback);
router.get('/', auth(['supervisor']), getFeedbacks);
router.post('/action', auth(['supervisor']), takeAction);
router.get('/all', auth(['admin']), getAllFeedbacks);

module.exports = router;