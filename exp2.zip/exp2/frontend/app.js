document.addEventListener('DOMContentLoaded', () => {
    const studentLoginForm = document.getElementById('studentLoginForm');
    const supervisorLoginForm = document.getElementById('supervisorLoginForm');
    const adminLoginForm = document.getElementById('adminLoginForm');
    const feedbackForm = document.getElementById('feedbackForm');
  
    if (studentLoginForm) {
      studentLoginForm.addEventListener('submit', handleStudentLogin);
    }
  
    if (supervisorLoginForm) {
      supervisorLoginForm.addEventListener('submit', handleSupervisorLogin);
    }
  
    if (adminLoginForm) {
      adminLoginForm.addEventListener('submit', handleAdminLogin);
    }
  
    if (feedbackForm) {
      feedbackForm.addEventListener('submit', handleSubmitFeedback);
    }
  
    function handleStudentLogin(event) {
      event.preventDefault();
      // Handle student login logic here
      window.location.href = 'student-dashboard.html';
    }
  
    function handleSupervisorLogin(event) {
      event.preventDefault();
      // Handle supervisor login logic here
      window.location.href = 'supervisor-dashboard.html';
    }
  
    function handleAdminLogin(event) {
      event.preventDefault();
      // Handle admin login logic here
      window.location.href = 'admin-dashboard.html';
    }
  
    async function handleSubmitFeedback(event) {
      event.preventDefault();
  
      const feedback = {
        mess: feedbackForm.mess.value,
        rating: feedbackForm.rating.value,
        comments: feedbackForm.comments.value,
      };
  
      try {
        const response = await fetch('http://localhost:3000/feedback', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(feedback),
        });
  
        if (response.ok) {
          alert('Feedback submitted successfully!');
          feedbackForm.reset();
        } else {
          alert('Failed to submit feedback.');
        }
      } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while submitting feedback.');
      }
    }
  });
  